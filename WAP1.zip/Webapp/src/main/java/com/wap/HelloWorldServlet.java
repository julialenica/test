package com.wap;

import java.io.*;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloWorldServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	public HelloWorldServlet() {
		System.out.println("Wywo�anie konstruktora");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		PrintWriter printWriter = response.getWriter();
		
		request.getParameter("string1");
		
		response.setContentType("text/html");
		
		printWriter.write("<html>\r\n" + 
				"<body>\r\n" + 
				"<h2>Hello World from servlet!</h2>\r\n" + 
				"</body>\r\n" + 
				"</html>\r\n" + 
				"");
	}

}
